# WP Audio (aplikasi pengaturan WP PROJECT AUDIO · BY SAIFULCKC)
Aplikasi Android yang membuka tampilan pengaturan alat (http://192.168.4.1) tanpa browser.
Aplikasi otomatis memakai jaringan WiFi alat walau WiFi itu tanpa internet.

## Build (pilih salah satu)
A. Android Studio: File > Open > folder ini > tunggu sync > Build > Build APK(s).
   Hasil: app/build/outputs/apk/debug/app-debug.apk
B. GitHub: unggah folder ini ke repo baru, buka tab Actions > Build APK > Run workflow,
   lalu unduh artefak "WP-Audio-apk".

## Pasang di HP
Salin APK ke HP, buka, izinkan "Pasang dari sumber ini" bila diminta.

## Pemakaian
1. Sambung WiFi alat, buka aplikasi WP Audio.
2. Tombol Back membuka menu: Muat ulang, Ubah alamat, Keluar.
   Ubah alamat dipakai bila alat tersambung ke WiFi rumah (IP lain, lihat menu Setup).
