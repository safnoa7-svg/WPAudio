package id.wpaudio.control;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.WindowManager;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;

public class MainActivity extends Activity {
    static final String DEF = "http://192.168.4.1";
    WebView web;
    ConnectivityManager cm;
    ConnectivityManager.NetworkCallback cb;
    boolean started;
    final Handler h = new Handler(Looper.getMainLooper());

    String url() { return getSharedPreferences("cfg", MODE_PRIVATE).getString("url", DEF); }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        web = new WebView(this);
        web.setBackgroundColor(0xFF0F1315);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String u = r.getUrl().toString();
                if (u.startsWith("wpapp://retry")) { connect(); return true; }
                if (u.startsWith("wpapp://addr")) { askAddr(); return true; }
                return false;
            }
            @Override public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame()) showError();
            }
        });
        cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        connect();
    }

    // Ikat aplikasi ke jaringan WiFi alat, walau WiFi itu tanpa internet dan data seluler aktif.
    void connect() {
        if (cb != null) { try { cm.unregisterNetworkCallback(cb); } catch (Exception ignored) { } }
        cm.bindProcessToNetwork(null);
        started = false;
        NetworkRequest rq = new NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI).build();
        cb = new ConnectivityManager.NetworkCallback() {
            @Override public void onAvailable(Network n) { cm.bindProcessToNetwork(n); h.post(MainActivity.this::go); }
            @Override public void onLost(Network n) { cm.bindProcessToNetwork(null); }
        };
        try { cm.requestNetwork(rq, cb); } catch (Exception ignored) { }
        h.postDelayed(this::go, 3000);
    }

    void go() { if (started) return; started = true; web.loadUrl(url()); }

    void showError() {
        String html = "<html><body style='margin:0;background:#0f1315;color:#e9edef;font-family:sans-serif;display:flex;min-height:100vh;align-items:center;justify-content:center'>"
            + "<div style='padding:28px;max-width:420px'><div style='color:#ff8a00;font-weight:700;letter-spacing:.3em;font-size:12px'>BY SAIFULCKC</div>"
            + "<h2 style='margin:6px 0 10px'>WP PROJECT AUDIO</h2><p style='color:#9aa7ae;line-height:1.5'>Tidak bisa terhubung ke alat. Sambungkan HP ke WiFi alat, lalu coba lagi.</p>"
            + "<p style='color:#9aa7ae'>Alamat: <b style='color:#fff'>" + url() + "</b></p>"
            + "<a href='wpapp://retry' style='display:block;background:#ff8a00;color:#1a0f00;text-align:center;padding:13px;border-radius:5px;font-weight:700;text-decoration:none;margin:18px 0 10px'>Coba lagi</a>"
            + "<a href='wpapp://addr' style='display:block;border:1px solid #2d373c;color:#e9edef;text-align:center;padding:13px;border-radius:5px;text-decoration:none'>Ubah alamat</a></div></body></html>";
        web.loadDataWithBaseURL(null, html, "text/html", "utf-8", null);
    }

    void askAddr() {
        final EditText et = new EditText(this);
        et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        et.setText(url());
        new AlertDialog.Builder(this).setTitle("Alamat alat").setView(et)
            .setPositiveButton("Simpan", (d, w) -> {
                String u = et.getText().toString().trim();
                if (u.isEmpty()) u = DEF;
                if (!u.startsWith("http")) u = "http://" + u;
                getSharedPreferences("cfg", MODE_PRIVATE).edit().putString("url", u).apply();
                connect();
            })
            .setNeutralButton("Bawaan", (d, w) -> {
                getSharedPreferences("cfg", MODE_PRIVATE).edit().putString("url", DEF).apply();
                connect();
            })
            .setNegativeButton("Batal", null).show();
    }

    @Override public void onBackPressed() {
        new AlertDialog.Builder(this).setItems(new String[]{"Muat ulang", "Ubah alamat", "Keluar"}, (d, i) -> {
            if (i == 0) connect(); else if (i == 1) askAddr(); else finish();
        }).show();
    }

    @Override protected void onResume() { super.onResume(); web.onResume(); }
    @Override protected void onPause() { web.onPause(); super.onPause(); }
    @Override protected void onDestroy() {
        try { cm.unregisterNetworkCallback(cb); } catch (Exception ignored) { }
        cm.bindProcessToNetwork(null);
        web.destroy();
        super.onDestroy();
    }
}
